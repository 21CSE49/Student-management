from django.urls import path
from . import views
from .views import logout_view
from .views import CustomLoginView

urlpatterns = [
  path('', views.index, name='index'),
  path('<int:id>', views.view_student, name='view_student'),
  path('logout/', logout_view, name='logout'),
  path('add/', views.add, name='add'),
  path('edit/<int:id>/', views.edit, name='edit'),
  path('delete/<int:id>/', views.delete, name='delete'),
  path('signin/', CustomLoginView.as_view(), name='signin'),

]
