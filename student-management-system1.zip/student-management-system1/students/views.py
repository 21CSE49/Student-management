from django.http import HttpResponseRedirect
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import logout
from django.contrib import messages
from .models import Student
from .forms import StudentForm
from django.contrib.auth.decorators import login_required
from django.contrib.auth.views import LoginView
from django.urls import reverse_lazy

# Ensure correct import of necessary modules

@login_required
def index(request):
    students = Student.objects.all()
    return render(request, 'students/index.html', {'students': students})

def view_student(request, id):
    student = get_object_or_404(Student, pk=id)
    return render(request, 'students/view_student.html', {'student': student})

@login_required
def add(request):
    if request.method == 'POST':
        form = StudentForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "Student added successfully.")
            return redirect('index')
    else:
        form = StudentForm()
    return render(request, 'students/add.html', {'form': form})

@login_required
def edit(request, id):
    student = get_object_or_404(Student, pk=id)
    if request.method == 'POST':
        form = StudentForm(request.POST, instance=student)
        if form.is_valid():
            form.save()
            messages.success(request, "Student updated successfully.")
            return redirect('index')
    else:
        form = StudentForm(instance=student)
    return render(request, 'students/edit.html', {'form': form})

@login_required
def delete(request, id):
    student = get_object_or_404(Student, pk=id)
    if request.method == 'POST':
        student.delete()
        messages.success(request, "Student deleted successfully.")
    return redirect('index')

def logout_view(request):
    logout(request)
    messages.success(request, "You have been logged out successfully.")
    return redirect('index')

class CustomLoginView(LoginView):
    template_name = 'students/signin.html'
    redirect_authenticated_user = True

    def get_success_url(self):
        return self.request.GET.get('next', reverse_lazy('index'))
